﻿<?php
$installer->validation($_SESSION['dbhost'],$_SESSION['dbname'],$_SESSION['dbuser'],$_SESSION['dbpass']);
echo '
<script>
document.getElementById("load").style.width="33%";
document.getElementById("percent").innerHTML=document.getElementById("load").style.width;
</script>
';
echo '
<script>
document.getElementById("load").style.width="66%";
document.getElementById("percent").innerHTML=document.getElementById("load").style.width;
</script>
';
$installer->extracter('data.zip','../');
echo '
<script>
document.getElementById("load").style.width="100%";
document.getElementById("percent").innerHTML=document.getElementById("load").style.width;
</script>
';
$installer->writethis($_SESSION['dbhost'],$_SESSION['dbname'],$_SESSION['dbuser'],$_SESSION['dbpass']);
$installer->dump($_SESSION['dbhost'],$_SESSION['dbname'],$_SESSION['dbuser'],$_SESSION['dbpass']);
echo '
<script>
document.getElementById("block").innerHTML=document.getElementById("block").innerHTML+"Установка завершена<br><br><button id=\'button\' OnClick=\'document.location.href = \\"index.php?page=5\\";\'>Завершить</button></div>";
</script>
';
?>