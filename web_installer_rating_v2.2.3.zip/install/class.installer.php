﻿<?php
class installer
{
function validation($dbhost,$dbname,$dblogin,$dbpass)
    {
//Объявляем перемнную, обозначающую код ошибки.
//на первом этапе она равна 0, что значит - ошибок нет
        $error=0;
//Если хоть одно из полей не введено
        if ($dbhost=="" or $dbname=="" or $dblogin=="")
        {
//Присваиваем код ошибки 1
            $error=1;
//если введены все поля
        }else{
//Пытаемся подключиться к серверу баз данных.
//Знак @ значит, что если подключиться не удастся,
//то выводить ошибку в окно браузера не нужно
            $subd_con = @mysqli_connect($dbhost,$dblogin,$dbpass);
            if (!$subd_con) //если подключиться не удалось
            {
                $error=2; //Присваиваем код ошибки 2
            }else{
                //На этом этапе мы узнаем, доступна ли выбранная база данных
                if (!@mysqli_select_db($dbname,$subd_con))
                {
                //Если нет, то код ошибки - 3
                    $error=3;
                }

            }
        }
        return $error;
    }
	function writethis($dbhost, $dbdatabase, $dbuser, $dbpassword)
    {
    $file = fopen ("../connect.php","r+");
      $str = '<?php
header(\'Content-Type: text/html; charset=utf-8\');
$dblocation = \''.$dbhost.'\'; // Имя сервера
$dbuser = \''.$dbuser.'\';          // Имя пользователя
$dbpasswd = \''.$dbpassword.'\';            // Пароль
$dbname=\''.$dbdatabase.'\';     //  Имя базы данных
$dbcnx = @mysqli_connect($dblocation,$dbuser,$dbpasswd,$dbname);
mysqli_query($dbcnx,"SET NAMES utf8");
if (!$dbcnx) // Если дескриптор равен 0 соединение не установлено
{
  echo("<P>В настоящий момент сервер базы данных не доступен, поэтому 
           корректное отображение страницы невозможно.</P>");
  exit();
}
			?>
      ';

    fputs ($file, $str);
      fclose ($file);
    }
	function dump($host,$database,$user,$password)
    {

     $dbhost=$host;
     $dblogin=$user;
     $dbpass=$password;
     $dbname=$database;

     $fname="dump.sql";
     //Подключаемся к серверу баз данных
        $db = mysqli_connect ($dbhost, $dblogin, $dbpass);
                  mysqli_select_db ($db, $dbname);

        if (!file_exists($fname)) die ("Файл $fname не существует!");
        $fp = fopen ($fname, "r");
        $buffer = fread($fp, filesize($fname));
        fclose ($fp);

        $prev = 0;
        while ($next = strpos($buffer,";",$prev+1))
        {
        $a = substr($buffer,$prev+1,$next-$prev);
        mysqli_query( $db, $a);
        $prev = $next;
        }
    }
	function extracter($arc_fille,$folder)
	{
	$zip = new ZipArchive;
if ($zip->open($arc_fille) === TRUE) {
    $zip->extractTo($folder);
    $zip->close();
} else {
    echo 'Ошибка извлечения';
}
	}
	}
?>